plugins { kotlin("jvm") }
kotlin { jvmToolchain(17) }
dependencies { testImplementation("junit:junit:4.13.2"); testImplementation("org.apache.pdfbox:pdfbox:2.0.32") }
